function getFriendlyNumbers(start, end) {
    return []
}

module.exports = {
    firstName: 'Name',
    secondName: 'Surname',
    task: getFriendlyNumbers
}